tall = 5
tall2 = 4 + tall
tall = 8
print(tall2)