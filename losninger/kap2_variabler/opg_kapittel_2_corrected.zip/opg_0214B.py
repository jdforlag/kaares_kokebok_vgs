prosent_for = 2.0
prosent_etter = 2.2
prosentpoeng = prosent_etter - prosent_for
prosent = (prosent_etter - prosent_for) / prosent_for * 100
print(f"Renten steg med {prosentpoeng} prosentpoeng, som tilsvarer en økning på {prosent} prosent.")