import math
radius = 5
hoyde = 2
volum = (math.pi * radius**2 * hoyde) / 3
print(f"Volumet av kjeglen er {volum:.2f} kubikkenheter.")