elever_tur = 15
prosent = 0.60
elever_total = elever_tur / prosent
print(f"Antall elever i klassen: {int(elever_total)}")