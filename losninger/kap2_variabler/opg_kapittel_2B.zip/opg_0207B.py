a = 4
b = 2
resultat = (a - b)**2 + 2 * b * (a - b) + b**2
print(f"Resultatet er {resultat}, som er lik (a+b)^2 = {a+b}^2 = {resultat}")