a = 4
a = a + 2 * a
a = a * 5
a = a - 4 * a
print(f"Verdien til a er {a}")