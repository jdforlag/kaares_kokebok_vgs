tall = int(input("Oppgi et heltall: "))
if tall % 4 == 0:
    print("Tallet er delelig med 4")
else:
    print("Tallet er ikke delelig med 4")