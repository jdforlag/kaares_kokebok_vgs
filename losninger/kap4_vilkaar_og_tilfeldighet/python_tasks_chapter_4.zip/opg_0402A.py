passord = input("Oppgi passord: ")
if passord == "matte123":
    print("Riktig passord")
else:
    print("Feil passord")