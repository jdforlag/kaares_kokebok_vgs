if 3 < 5:
    print("Det stemmer")