tall = int(input("Oppgi et heltall: "))
if tall > 0:
    print("Positivt")
else:
    print("Ikke positivt")